package com.eric.car;

public class Car {
// attribute
	protected int gas;
	protected boolean gameO;
//	CONSTRUCTOR

	public Car() {
		this.gas = 10;
		this.gameO = false;
	}
	
// METHODS
	public void displayGas() {
		System.out.println(getGas());
	}
	public void gameOver() {
		if (gameO = true) {
		System.out.println("GAME OVER!");
		}
	}
	public void gameover() {
		if (this.gas = 0) {
		System.out.println("GAME OVER!");
		}
	}

// GETTERS / SETTERS
		public int getGas() {
			return gas;
		}

		public void setGas(int gas) {
			this.gas = gas;
		}

}
