package com.eric.car;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Driver actions = new Driver();
		
		actions.drive();
		actions.drive();
		actions.drive();
		actions.drive();
		
		actions.boosters();
		
		actions.refuel();
		actions.refuel();
		actions.refuel();
		
		
	}

}
